package com.heyniu.monitor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MonitorReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(MonitorService.TAG, "Received broadcast >> " + MonitorReceiver.class.getSimpleName());
        if (intent == null) return;
        String packageName = intent.getStringExtra(SharedPreferencesHelper.PACKAGE);
        String cls = intent.getStringExtra(SharedPreferencesHelper.CLASS);
        String runner = intent.getStringExtra(SharedPreferencesHelper.RUNNER);

        Log.d(MonitorService.TAG, "Monitor target application: " + packageName);
        Log.d(MonitorService.TAG, "Class: " + cls);

        SharedPreferencesHelper sharedPreferences = new SharedPreferencesHelper(
                context.getApplicationContext(), SharedPreferencesHelper.PARAMS);

        sharedPreferences.putString(SharedPreferencesHelper.PACKAGE, packageName);
        sharedPreferences.putString(SharedPreferencesHelper.CLASS, cls);
        sharedPreferences.putString(SharedPreferencesHelper.RUNNER, runner);

        PollingUtils.startPollingService(context, 60, MonitorService.class, MonitorService.ACTION);
    }
}
