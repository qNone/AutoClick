package com.heyniu.monitor;


import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ShellUtils {

    public static StringBuilder getRuntime(String command){
        StringBuilder sb = new StringBuilder();
        Process p = null;
        try {
            p = Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (p != null){
            BufferedInputStream in = new BufferedInputStream(p.getInputStream());
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line;
            try {
                while ((line = br.readLine()) != null) {
                    sb.append(line).append(System.getProperty("line.separator"));
                }
                in.close();
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb;
    }

    /**
     * 判断进程是否在运行
     * @param packageName 包名
     * @return process is running?
     */
    public static boolean isRunning(String packageName){
        String result = getRuntime("ps | grep -w " + packageName).toString();
        Log.d(MonitorService.TAG, result);
        return result.contains(packageName);
    }

}
