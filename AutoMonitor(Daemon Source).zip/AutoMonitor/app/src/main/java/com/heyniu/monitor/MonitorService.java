package com.heyniu.monitor;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.support.v7.app.NotificationCompat;
import android.text.TextUtils;
import android.util.Log;

import java.io.File;
import java.io.FilenameFilter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MonitorService extends Service {

	private SharedPreferencesHelper sharedPreferences;
	private ServiceHandler mServiceHandler;
	private NotificationCompat.Builder builder;
	private NotificationManager manager;
	public static final String TAG = "Robotium";
	public static final String ACTION = "com.heyniu.Auto.Monitor";
	public static final String SAVE_PATH = "/AutoClick/";
	private static final int NOTIFY = 10000;

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		// Start up the thread running the service. Note that we create a
		// separate thread because the service normally runs in the process's
		// main thread, which we don't want to block. We also make it
		// background priority so CPU-intensive work will not disrupt our UI.
		Log.i(TAG, "Service onCreate");
		sharedPreferences = new SharedPreferencesHelper(getApplicationContext(), SharedPreferencesHelper.PARAMS);
		HandlerThread thread = new HandlerThread("ServiceStartArguments", Process.THREAD_PRIORITY_BACKGROUND);
		thread.start();
		// Get the HandlerThread's Looper and use it for our Handler
		Looper mLooper = thread.getLooper();
		mServiceHandler = new ServiceHandler(mLooper);
		initNotificationManager();
	}

	private void initNotificationManager() {
		Bitmap bitmap = BitmapFactory.decodeResource(getApplicationContext().getResources(), com.heyniu.monitor.R.mipmap.ic_launcher);
		Intent intent = new Intent(getApplicationContext(), MainActivity.class);
		PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
		builder = new NotificationCompat.Builder(getApplicationContext());
		builder.setContentTitle("Monitor");
		builder.setContentText("On standby.");
		builder.setContentIntent(pendingIntent);
		builder.setSmallIcon(com.heyniu.monitor.R.drawable.coffee);
		builder.setLargeIcon(bitmap);
		builder.setAutoCancel(true);
		manager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
	}

	private void showNotificationManager(String context) {
		//send notify.
		builder.setContentText(context);
		Notification notify = builder.build();
		manager.notify(NOTIFY, notify);
	}

	private void startInstrumentation() {
		String pkg = sharedPreferences.getString(SharedPreferencesHelper.PACKAGE);
		String cls = sharedPreferences.getString(SharedPreferencesHelper.CLASS);
		String runner = sharedPreferences.getString(SharedPreferencesHelper.RUNNER);

		ComponentName cn = new ComponentName(pkg + ".test", runner);

		Bundle bundle = new Bundle();
		bundle.putBoolean(SharedPreferencesHelper.DEBUG, false);
		bundle.putString(SharedPreferencesHelper.CLASS, cls);
		bundle.putString(SharedPreferencesHelper.NEW_REPTILE, "false");
		bundle.putString(SharedPreferencesHelper.USE_NATIVE, "true");

		startInstrumentation(cn, null, bundle);
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Log.i(TAG, "Service starting");
		// For each start request, send a message to start a job and deliver the
		// start ID so we know which request we're stopping when we finish the
		// job
		if (intent != null) {
			boolean isStart = intent.getBooleanExtra(PollingUtils.START, false);
			if (isStart) {
				Message msg = mServiceHandler.obtainMessage();
				msg.arg1 = startId;
				mServiceHandler.sendMessage(msg);
			}
		}
		// If we get killed, after returning from here, restart
		return START_STICKY;
	}

	@Override
	public void onDestroy() {
		Log.i(TAG, "Service done");
	}

	// Handler that receives messages from the thread
	private final class ServiceHandler extends Handler {

		ServiceHandler(Looper looper) {
			super(looper);
		}

		@Override
		public void handleMessage(Message msg) {
			// Normally we would do some work here, like download a file.
			// For our sample, we just sleep for 5 seconds.
			Log.i(TAG, "Service running...");
			String pkg = sharedPreferences.getString(SharedPreferencesHelper.PACKAGE);
			if (!TextUtils.isEmpty(pkg)) {
				Log.i(TAG, pkg);
				boolean b = ShellUtils.isRunning(pkg);
				showNotificationManager(b ? pkg + " is running..." : pkg + " is stopped.");
				Log.i(TAG, b ? pkg + " is running..." : pkg + " is stopped.");
				if (!b) {
					startInstrumentation();
				} else {
					File targetFile = getTargetFile(pkg);
					if (targetFile != null && targetFile.exists()) {
						Log.i(TAG, targetFile.getAbsolutePath());
						String newMd5 = MD5Utils.getMd5ByFile(targetFile);
						String oldMd5 = MD5Utils.getMD5(sharedPreferences);
						if (newMd5.equals(oldMd5)) {
							startInstrumentation();
						}
						MD5Utils.putMD5(sharedPreferences, newMd5);
					}
				}
			}

			// Stop the service using the startId, so that we don't stop
			// the service in the middle of handling another job
			stopSelf(msg.arg1);
		}
	}

	private File getTargetFile(String pkg) {
		File filePath = new File(Environment.getExternalStorageDirectory(),
				SAVE_PATH + pkg + "/Log/");
		File targetFile = null;
		long time = 0L;
		if (filePath.isDirectory()) {
			File[] files = filePath.listFiles();
			Pattern pattern = Pattern.compile("Log-(\\d+)\\.log");
			for (File file: files) {
				String name = file.getName();
				Log.i(TAG, name);
				Matcher matcher = pattern.matcher(name);
				if (matcher.matches()) {
					long temp = Long.valueOf(matcher.group(1));
					if (temp > time) {
						time = temp;
						targetFile = file;
					}
				}
			}
		}
		return targetFile;
	}

}
