package com.heyniu.monitor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class QuitReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(MonitorService.TAG, "Received broadcast >> " + QuitReceiver.class.getSimpleName());
        PollingUtils.stopPollingService(context, MonitorService.class, MonitorService.ACTION);
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(0);
    }
}
